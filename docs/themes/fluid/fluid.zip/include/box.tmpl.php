<?php if (!defined('AT_INCLUDE_PATH')) { exit; } ?>

<h2><?php echo $this->title; ?></h2>
<div class="box">
	<?php echo $this->dropdown_contents; ?>
</div>