<?php
/************************************************************************/
/* ATutor																*/
/************************************************************************/
/* Copyright (c) 2002-2005 by Greg Gay, Joel Kronenberg & Heidi Hazelton*/
/* Adaptive Technology Resource Centre / University of Toronto			*/
/* http://atutor.ca														*/
/*																		*/
/* This program is free software. You can redistribute it and/or		*/
/* modify it under the terms of the GNU General Public License			*/
/* as published by the Free Software Foundation.						*/
/************************************************************************/

/* This is the default configuration file for the default theme. */

/* The theme's name. */
	$_theme['name'] = 'Navy Side';

/* The theme's version number. */
	$_theme['version'] = '0.1';

/* Which version of ATutor is this theme intended for. */
	$_theme['atutor-version'] = '1.4.3';

/* author information */
	$_theme['author_name']  = 'heidi hazelton';
	$_theme['author_url']   = '';
	$_theme['author_email'] = 'heidi.hazelton@utoronto.ca';


/* theme specific functions */
function print_nav_recursive($current_page, $path) {
	global $_pages;
	global $_base_path;
	static $this_page;

	if (!$this_page) {
		$this_page = substr($_SERVER['PHP_SELF'], strlen($_base_path));
	}

	if (is_numeric($current_page)) {
		$children = $_pages[$current_page];
	} else {
		$children = $_pages[$current_page]['children'];
	}
	echo '<div style="margin-left:-30px;">';
	echo '<ul style="list-style: none;">';
	if ($children) {
		foreach($children as $page) {
			echo '<li>';
			if ($page == $this_page) {
				echo _AT($_pages[$page]['title_var']);
			} else {
				echo '<a href="'.$_base_path . $page.'">'._AT($_pages[$page]['title_var']).'</a>';
			}
			if ($path[$page]) {
				print_nav_recursive($page, $path);
			}
			echo '</li>';
		}
	} else {
		foreach($path as $temp_path => $garbage) {
			if (!($_pages[$temp_path]['ignore']) && $_pages[$temp_path]['parent'] == $current_page) {
				echo '<li>';
				if ($_pages[$temp_path]['title_var'] == '') {
					$title = $_pages[$temp_path]['title'];
				} else {
					$title = _AT($_pages[$temp_path]['title_var']);
				}
				if ($temp_path == $this_page) {
					echo $title;
				} else {
					echo '<a href="'.$_base_path.$temp_path.'">'.$title.'</a>';
				}
				print_nav_recursive($temp_path, $path);
				echo '</li>';
			}
		}
	}
	echo '</ul>';
	echo '</div>';
}

?>