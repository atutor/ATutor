
Theme:		Clean Blue
Date:		June 2004

Notes:		-Doesn't make use of the instructor's custom banner
		-Icons-only preference for Course Navigation not possible
		-Doesn't use HEADER_IMAGE setting in config.inc.php

Installing:	See section "Installing a New Theme" in the themes_readme.txt file located in docs/themes/.

Licence:	Falls under the GPL agreement.  See http://www.gnu.org/copyleft/gpl.html.
	