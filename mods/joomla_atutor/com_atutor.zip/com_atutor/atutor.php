<?php
/*
* This is the ATutor bridge component for Mambo Open Source
* Created by Cas Nuy March 2005
*/

if (!defined('atutor')){
  global $mosConfig_absolute_path;

  require ($mosConfig_absolute_path."/administrator/components/com_atutor/config.atutor.php");
}

if (!defined("_MOS_ALLOWHTML")){
  define( "_MOS_ALLOWHTML", 0x0002 );
}

$my_id = $my->id;
$name='';
$mail='';
$sql = "SELECT username,email FROM ".$mos_prefix."users WHERE id=$my_id";
$result = mysql_query ($sql);
if (isset($result)) {
	$row = mysql_fetch_array($result);
	$name= $row[0] ;
	$email= $row[1] ;
}

$check = $name ;
$check .= "|" ;
$check .= $email ;

$scripturl = $atutor_path ;
$scripturl .= "/index_mambo.php?parm=" ;
$scripturl .= $check ;

if ($window == 'y' ) {
	?>
	<script type="text/javascript">
	window.open('<?php echo $scripturl;?>')
	</script>
	<?php
	echo "ATutor launched in new window";
} else {
	echo "<script language='javascript' type='text/javascript'>";
	echo "function iFrameHeight() {";
	echo "  var h = 0;";
	echo "	if ( !document.all ) {";
	echo "		h = document.getElementById('blockrandom').contentDocument.height;";
	echo "		document.getElementById('blockrandom').style.height = h + 60 + 'px';";
	echo "	} else if( document.all ) {";
	echo "		h = document.frames('blockrandom').document.body.scrollHeight;";
	echo "		document.all.blockrandom.style.height = h + 20 + 'px';";
	echo "	}";
	echo "}";
	echo "</script>";
	echo "<iframe onload='iFrameHeight()' id='blockrandom' name='MamboATutor'";
	echo "  src='$scripturl' width='100%' height='400' scrolling='auto' align='top' frameborder='0'>";
	echo "</iframe>";
}
?>
