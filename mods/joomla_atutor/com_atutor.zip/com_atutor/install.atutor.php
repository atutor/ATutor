<?
function com_install() {
global $database;

# Set up new icons for admin menu
$database->setQuery("UPDATE #__components SET admin_menu_img='js/ThemeOffice/config.png' WHERE admin_menu_link='option=com_atutor&task=config'");
$iconresult[1] = $database->query();

# Show installation result to user
?>
<center>
<table width="100%" border="0">
  <tr>
    <td>
      <strong>ATutor Bridge Component</strong><br/>
      <br/>
      This component is released under the terms and conditions of the <a href="index2.php?option=com_admisc&task=license">GNU General Public License</a>.
    </td>
  </tr>
  <tr>
    <td>
      <code>Installation: <font color="green">succesful</font></code>
    </td>
  </tr>
</table>
</center>
<?
}
?>
