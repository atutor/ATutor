<?php /* $Id $ */

 /**
 * ATutor Menubar Handler
 * @package MOS-Atutor bridge by Cas Nuy
 * @license http://www.gnu.org/copyleft/gpl.html. GNU Public License
 * @version 1.0
 */

// Ensure this file is being included by a parent file.
defined('_VALID_MOS') or die('Direct Access to this location is not allowed.');

class TOOLBAR_atutor
{
	/**
	 * Draws the menu to add or edit an item
	 */
	function _EDIT()
	{
		mosMenuBar::startTable();
		mosMenuBar::save();
		mosMenuBar::cancel();
		mosMenuBar::spacer();
		mosMenuBar::endTable();
	}

	function _DEFAULT()
	{
		mosMenuBar::startTable();
		mosMenuBar::save();
		mosMenuBar::cancel();
		mosMenuBar::spacer();
		mosMenuBar::endTable();
	}
}

?>
