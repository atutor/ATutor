<?php

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


switch ($task) {
	  case "config":

    showConfig( $option );

    break;



  case "save":

    saveConfig ($option,$atutor_path,$mos_prefix,$window);

    break;
}


function showConfig( $option ) {

  global $mosConfig_absolute_path, $database;

  require($mosConfig_absolute_path."/administrator/components/com_atutor/config.atutor.php");

?>

    <script language="javascript" type="text/javascript">

    function submitbutton(pressbutton) {

      var form = document.adminForm;


        submitform( pressbutton );

        return;

    }

    </script>



  <form action="index2.php" method="POST" name="adminForm">

  <table cellpadding="4" cellspacing="0" border="0" width="100%">

  <tr>

    <td width="100%" class="sectionname">

      <!-- <img src="mos_atutor_logo.jpg"> -->

    </td>

  </tr>

  </table>

<script language="javascript" src="js/dhtml.js"></script>


  <table width="100%" border="0" cellpadding="4" cellspacing="2" class="adminForm">

    <tr align="center" valign="middle">

      <td align="left" valign="top"><strong>Path to ATutor (AN URL!!):</strong></td>

      <td align="left" valign="top"><input type="text" name="atutor_path" value="<? echo "$atutor_path"; ?>"></td>

	</tr>
	<tr align="center" valign="middle">

      <td align="left" valign="top"><strong>Mambo database prefix:</strong></td>

      <td align="left" valign="top"><input type="text" name="mos_prefix" value="<? echo "$mos_prefix"; ?>"></td>

	</tr>
	<tr align="center" valign="middle">

      <td align="left" valign="top"><strong>Open in New Window Y/N:</strong></td>

      <td align="left" valign="top"><input type="text" name="window" value="<? echo "$window"; ?>"></td>

	</tr>
   <input type="hidden" name="option" value="<?php echo $option; ?>">

  <input type="hidden" name="act" value="<?php echo $act; ?>">

  <input type="hidden" name="task" value="">

  <input type="hidden" name="boxchecked" value="0">

</form>

<?php

}

function saveConfig ($option,$atutor_path,$mos_prefix,$window) {

  $configfile = "components/com_atutor/config.atutor.php";

  @chmod ($configfile, 0766);

  $permission = is_writable($configfile);

  if (!$permission) {

    $mosmsg = "Config file not writeable!";

    mosRedirect("index2.php?option=$option&act=config",$mosmsg);

    break;

  }


 $config  = "<?php\n";

  $config  .= "global \$atutor_path,\$mos_prefix;\n";

  $config  .= "\$atutor_path = \"$atutor_path\";\n";

  $config  .= "\$mos_prefix = \"$mos_prefix\";\n";

  $config  .= "\$window = \"$window\";\n";

  $config  .= "?>";



  if ($fp = fopen("$configfile", "w")) {

    fputs($fp, $config, strlen($config));

    fclose ($fp);

}
  mosRedirect("index2.php?option=$option&task=config", "Settings saved");

}
