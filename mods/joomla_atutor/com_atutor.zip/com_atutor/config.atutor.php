<?php
global $atutor_path;
$atutor_path = "/atutor";
$mos_prefix = "mos_";
$window ="y" ;
?>
